%Adam Wirehed TME136
function gear_demand = student_AutomaticGearbox(Gear, RPM, LongAcc, Velocity, Throttle, Distance, TimeLap)
    
    %Distanser d�r bilen ska v�xla
    D = Distance;
    a = 30.000;
    b = 63.000;
    c = 164.000;
    %Om bilen �r i intervallet 0-30m ska den k�ra i ettans v�xel
    if D < a
        gear_demand = 1;
    %Om bilen �r i intervallet 30-65m ska den k�ra i tv�ans v�xel
    elseif D > a && D < b
        gear_demand =2;
    %Om bilen �r i intervallet 60-160m ska den k�ra i treans v�xel
    elseif D > b && D < c
        gear_demand = 3;
    %Efter 160m ska bilen k�ra i fyrans v�xel
    elseif D > c
        gear_demand = 4;
    end

end